import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAppLock } from "../context/AppLockContext";
import { showAlert } from "../components/CustomAlert";
import NeuBox from "../components/NeuBox";
import { getFullUsage } from "../utils/usageTracker";
import {
  getLevel, getNextLevel, getLevelProgress, getXPInLevel, getXPForLevel,
  getUnlockedAchievements, ACHIEVEMENT_DEFS,
} from "../utils/pigWeight";
import { lightTap } from "../utils/haptics";

const PIG_FLOAT = require("../../assets/pig-float.png");
const { width: SCREEN_W } = Dimensions.get("window");

export default function StatsScreen() {
  const { state } = useAppLock();
  const [usage, setUsage] = useState(null);

  useEffect(() => {
    getFullUsage().then(setUsage);
  }, [state.totalUnlocks]);

  const xp = state.totalCoinsSpent;
  const level = getLevel(xp);
  const nextLevel = getNextLevel(xp);
  const progress = getLevelProgress(xp);
  const xpInLevel = getXPInLevel(xp);
  const xpForLevel = getXPForLevel(xp);
  const achievements = getUnlockedAchievements(state);

  return (
    <LinearGradient colors={["#EDE8E4", "#F5CCD5"]} style={styles.gradient}>
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

          {/* Header */}
          <Text style={styles.title}>SHAME STATS</Text>
          <Text style={styles.subtitle}>I'm keeping score</Text>

          {/* Hero Pig + Level */}
          <View style={styles.heroCard}>
            <View style={styles.levelBadge}>
              <LinearGradient colors={["#FF69B4", "#FF8AC6"]} style={styles.levelBadgeGrad}>
                <Text style={styles.levelBadgeText}>✦ LEVEL {level.level} ✦</Text>
              </LinearGradient>
            </View>
            <Image source={PIG_FLOAT} style={styles.heroPig} resizeMode="contain" />
            <Text style={styles.tierName}>{level.tier}</Text>
            {level.cosmetic && (
              <View style={styles.cosmeticPill}>
                <Text style={styles.cosmeticText}>🎁 {level.cosmetic}</Text>
              </View>
            )}
          </View>

          {/* XP Progress Bar */}
          <NeuBox style={styles.xpCard} borderRadius={20} bg="#FFFFFF" borderColor="rgba(255,255,255,0.9)">
            <View style={styles.xpHeader}>
              <Text style={styles.xpLabel}>Level {level.level}: {level.tier}</Text>
              <Text style={styles.xpValue}>{xp}</Text>
            </View>
            <View style={styles.xpLevelRow}>
              <Text style={styles.xpLevelText}>Lv.{level.level}</Text>
              <Text style={styles.xpAmountText}>{xpInLevel} / {xpForLevel || "MAX"}</Text>
              {nextLevel && <Text style={styles.xpLevelText}>Lv.{nextLevel.level}</Text>}
            </View>
            <View style={styles.xpBarTrack}>
              <LinearGradient
                colors={["#FF69B4", "#FF8AC6"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.xpBarFill, { width: `${Math.max(2, progress * 100)}%` }]}
              />
            </View>
            {nextLevel ? (
              <Text style={styles.xpRemaining}>Spend {nextLevel.xpRequired - xp} more coins to reach {nextLevel.tier}</Text>
            ) : (
              <Text style={styles.xpRemaining}>MAX LEVEL. Absolute unit.</Text>
            )}
          </NeuBox>

          {/* Stats Grid */}
          <View style={styles.statsRow}>
            <StatCard value={`${usage?.screenTimeToday || 0}m`} label="Scroll Time Today" />
            <StatCard value={state.totalUnlocks} label="Total Tributes" pink />
          </View>
          <View style={styles.statsRow}>
            <StatCard value={state.totalCoinsSpent} label="Total Coins Spent" />
            <StatCard value={usage?.opensToday || 0} label="App Opens Today" />
          </View>

          {/* Streaks */}
          {(state.ironSnoutStreak > 0 || state.bestIronSnout > 0) && (
            <View style={styles.statsRow}>
              <StatCard value={state.ironSnoutStreak} label="Iron Snout" color="#FF6B35" />
              <StatCard value={state.bestIronSnout} label="Best Streak" />
            </View>
          )}

          {/* Achievements */}
          <NeuBox style={styles.achieveCard} borderRadius={20} bg="#FFFFFF" borderColor="rgba(255,255,255,0.9)">
            <View style={styles.achieveHeader}>
              <Text style={styles.sectionLabel}>ACHIEVEMENTS</Text>
              <Text style={styles.achieveCount}>+{achievements.length} Earned</Text>
            </View>
            <View style={styles.achieveGrid}>
              {ACHIEVEMENT_DEFS.slice(0, 6).map((a) => {
                const unlocked = achievements.some((u) => u.id === a.id);
                return (
                  <TouchableOpacity
                    key={a.id}
                    style={[styles.achieveBadge, !unlocked && styles.achieveLocked]}
                    activeOpacity={0.7}
                    onPress={() => showAlert(a.name, a.desc)}
                  >
                    <Text style={styles.achieveIcon}>{a.icon}</Text>
                    <Text style={[styles.achieveName, !unlocked && styles.achieveNameLocked]} numberOfLines={1}>{a.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </NeuBox>

        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

function StatCard({ value, label, pink, color }) {
  return (
    <NeuBox style={styles.statCard} borderRadius={16} bg="#FFFFFF" borderColor="rgba(255,255,255,0.9)">
      <Text style={[styles.statValue, pink && { color: "#FF69B4" }, color && { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </NeuBox>
  );
}

const styles = StyleSheet.create({
  gradient: { flex: 1 },
  safe: { flex: 1 },
  scroll: { paddingHorizontal: 24, paddingBottom: 40 },

  title: { fontSize: 28, fontWeight: "900", color: "#4A2040", letterSpacing: -1, textTransform: "uppercase", marginTop: 12 },
  subtitle: { fontSize: 12, fontWeight: "300", color: "#B898A8", letterSpacing: 1, textTransform: "uppercase", marginTop: 2, marginBottom: 20 },

  heroCard: { alignItems: "center", marginBottom: 16 },
  levelBadge: { marginBottom: -12, zIndex: 2 },
  levelBadgeGrad: { paddingHorizontal: 20, paddingVertical: 6, borderRadius: 16 },
  levelBadgeText: { fontSize: 14, fontWeight: "900", color: "#FFFFFF", letterSpacing: 1 },
  heroPig: { width: 200, height: 200 },
  tierName: { fontSize: 22, fontWeight: "900", color: "#FF69B4", letterSpacing: -0.5, marginTop: 8 },
  cosmeticPill: { backgroundColor: "#FFD6EB", borderRadius: 12, paddingHorizontal: 14, paddingVertical: 4, marginTop: 6 },
  cosmeticText: { fontSize: 12, fontWeight: "700", color: "#FF69B4" },

  xpCard: { marginBottom: 16, padding: 18 },
  xpHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  xpLabel: { fontSize: 13, fontWeight: "800", color: "#4A2040", letterSpacing: -0.3 },
  xpValue: { fontSize: 14, fontWeight: "900", color: "#FF69B4" },
  xpLevelRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  xpLevelText: { fontSize: 12, fontWeight: "700", color: "#B898A8" },
  xpAmountText: { fontSize: 16, fontWeight: "900", color: "#4A2040" },
  xpBarTrack: { height: 8, borderRadius: 4, backgroundColor: "#FFD6EB", overflow: "hidden", marginBottom: 8 },
  xpBarFill: { height: "100%", borderRadius: 4 },
  xpRemaining: { fontSize: 11, fontWeight: "500", color: "#B898A8", textAlign: "center" },

  statsRow: { flexDirection: "row", gap: 10, marginBottom: 10 },
  statCard: { flex: 1, height: 90, alignItems: "center", justifyContent: "center", padding: 12 },
  statValue: { fontSize: 24, fontWeight: "900", color: "#4A2040", letterSpacing: -1 },
  statLabel: { fontSize: 10, fontWeight: "600", color: "#B898A8", letterSpacing: 0.5, textTransform: "uppercase", marginTop: 4, textAlign: "center" },

  sectionLabel: { fontSize: 11, fontWeight: "800", color: "#B898A8", letterSpacing: 1.5, textTransform: "uppercase" },

  achieveCard: { marginBottom: 16, padding: 18 },
  achieveHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  achieveCount: { fontSize: 12, fontWeight: "700", color: "#FF69B4" },
  achieveGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  achieveBadge: { width: (SCREEN_W - 48 - 36 - 20) / 3, backgroundColor: "#FFF5FA", borderRadius: 14, padding: 12, alignItems: "center" },
  achieveLocked: { opacity: 0.35 },
  achieveIcon: { fontSize: 24, marginBottom: 4 },
  achieveName: { fontSize: 10, fontWeight: "700", color: "#4A2040", textAlign: "center" },
  achieveNameLocked: { color: "#B898A8" },

});
