import React from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import NeuBox from "../components/NeuBox";
import { getLevel, getNextLevel, getLevelProgress, getXPInLevel, getXPForLevel, getNewAchievements } from "../utils/pigWeight";
import { C } from "../utils/theme";
import { lightTap, successTap } from "../utils/haptics";

const PIG_FLOAT = require("../../assets/pig-float.png");
const { width: SCREEN_W } = Dimensions.get("window");

const PIG_REACTIONS = [
  "You really committed to the slop. I'm simultaneously disgusted and impressed. Oink.",
  "Another level? You're pathetic and I love it.",
  "Look at you, growing fatter by the day. Your master approves.",
  "Congratulations on being even more addicted. Proud of you, pig.",
  "You think leveling up makes you special? It just means you're deeper in the trough.",
  "Every level is a monument to your weakness. Keep going.",
];

export default function LevelUpScreen({ navigation, route }) {
  const { fromLevel, toLevel, xp, achievements = [] } = route.params || {};
  const from = fromLevel || { level: 1, tier: "Runt" };
  const to = toLevel || { level: 2, tier: "Scrawny Pig" };
  const totalXP = xp || 0;
  const nextLevel = getNextLevel(totalXP);
  const progress = getLevelProgress(totalXP);
  const xpInLevel = getXPInLevel(totalXP);
  const xpForLevel = getXPForLevel(totalXP);
  const reaction = PIG_REACTIONS[to.level % PIG_REACTIONS.length];

  const handleShare = async (method) => {
    lightTap();
    try {
      await Share.share({
        message: `🐷 I just reached Level ${to.level} — "${to.tier}" in Scroll Pig! I'm disgusting and I know it.`,
      });
    } catch (e) {}
  };

  return (
    <LinearGradient colors={["#EDE8E4", "#F5CCD5"]} style={styles.gradient}>
      <SafeAreaView style={styles.safe}>
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

          {/* Hero */}
          <View style={styles.hero}>
            <LinearGradient colors={["#FF69B4", "#FF8AC6"]} style={styles.levelBadge}>
              <Text style={styles.levelBadgeText}>✦ LEVEL {to.level} ✦</Text>
            </LinearGradient>
            <Image source={PIG_FLOAT} style={styles.heroPig} resizeMode="contain" />
            <Text style={styles.heroTitle}>{to.tier} Unlocked!</Text>
            <Text style={styles.heroSub}>You've leveled up your disgusting pig 🐷</Text>
            <View style={styles.statPills}>
              {to.cosmetic && <Pill text={`🎁 ${to.cosmetic}`} />}
              <Pill text={`Lv.${to.level}`} />
            </View>
          </View>

          {/* What Changed */}
          <NeuBox style={styles.card} borderRadius={20} bg="#FFFFFF" borderColor="rgba(255,255,255,0.9)">
            <View style={styles.cardHeader}>
              <Text style={styles.sectionLabel}>WHAT CHANGED</Text>
            </View>

            <ChangeRow label="LEVEL NUMBER" left={`Lv. ${from.level}`} right={`Lv. ${to.level}`} rightHighlight tag="NEW!" />
            <ChangeRow label="PIG MASCOT" left={from.tier} right={to.tier} rightHighlight />
            {to.cosmetic && (
              <View style={styles.cosmeticRow}>
                <View style={styles.cosmeticUnlocked}>
                  <Text style={styles.cosmeticUnlockedText}>🔓 UNLOCKED  COSMETIC</Text>
                </View>
                <Text style={styles.cosmeticName}>"{to.cosmetic}"</Text>
                <Text style={styles.cosmeticDesc}>Exclusive Lv.{to.level} headpiece for your pig</Text>
              </View>
            )}

            {/* XP Progress */}
            <View style={styles.xpSection}>
              <View style={styles.xpHeader}>
                <Text style={styles.xpLabel}>XP PROGRESS</Text>
                <Text style={styles.xpBadge}>🔥 {totalXP} XP</Text>
              </View>
              <Text style={styles.xpLevelLabel}>Level {to.level} → {to.tier}</Text>
              <View style={styles.xpBarTrack}>
                <LinearGradient
                  colors={["#FF69B4", "#FF8AC6"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[styles.xpBarFill, { width: `${Math.max(2, progress * 100)}%` }]}
                />
              </View>
              <View style={styles.xpLabels}>
                <Text style={styles.xpSmall}>Lv.{to.level} start</Text>
                <Text style={styles.xpSmall}>{nextLevel ? `${nextLevel.xpRequired - totalXP} XP to Lv.${nextLevel.level}` : "MAX"}</Text>
              </View>
            </View>
          </NeuBox>

          {/* Achievements */}
          {achievements.length > 0 && (
            <NeuBox style={styles.card} borderRadius={20} bg="#FFFFFF" borderColor="rgba(255,255,255,0.9)">
              <View style={styles.cardHeader}>
                <Text style={styles.sectionLabel}>ACHIEVEMENTS EARNED</Text>
                <Text style={styles.achieveCount}>+{achievements.length} New</Text>
              </View>
              <View style={styles.achieveRow}>
                {achievements.map((a) => (
                  <View key={a.id} style={styles.achieveBadge}>
                    <Text style={styles.achieveIcon}>{a.icon}</Text>
                    <Text style={styles.achieveName}>{a.name}</Text>
                    <Text style={styles.achieveDesc}>{a.desc}</Text>
                  </View>
                ))}
              </View>
            </NeuBox>
          )}

          {/* Share */}
          <NeuBox style={styles.card} borderRadius={20} bg="#FFFFFF" borderColor="rgba(255,255,255,0.9)">
            <Text style={styles.sectionLabel}>SHARE YOUR SHAME</Text>
            <Text style={styles.shareDesc}>Let everyone know your pig leveled up</Text>
            <View style={styles.shareRow}>
              {["Story", "Post", "Copy"].map((m) => (
                <TouchableOpacity key={m} style={styles.shareBtn} activeOpacity={0.7} onPress={() => handleShare(m)}>
                  <Text style={styles.shareBtnText}>{m}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </NeuBox>

          {/* CTA */}
          <TouchableOpacity
            style={styles.rewardsBtn}
            activeOpacity={0.85}
            onPress={() => { successTap(); navigation.goBack(); }}
          >
            <LinearGradient colors={["#FF69B4", "#FF8AC6"]} style={styles.rewardsBtnGrad}>
              <Text style={styles.rewardsBtnText}>Continue to Home →</Text>
            </LinearGradient>
          </TouchableOpacity>

          {/* Pig Reaction */}
          <View style={styles.reactionCard}>
            <Text style={styles.reactionLabel}>PIG'S REACTION</Text>
            <Text style={styles.reactionText}>"{reaction}"</Text>
          </View>

        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

function Pill({ text }) {
  return (
    <View style={styles.pill}>
      <Text style={styles.pillText}>{text}</Text>
    </View>
  );
}

function ChangeRow({ label, left, right, rightHighlight, tag }) {
  return (
    <View style={styles.changeRow}>
      <Text style={styles.changeLabel}>{label}</Text>
      <View style={styles.changeValues}>
        <Text style={styles.changeLeft}>{left}</Text>
        <Text style={styles.changeArrow}>→</Text>
        <Text style={[styles.changeRight, rightHighlight && { color: "#FF69B4", fontWeight: "900" }]}>{right}</Text>
        {tag && <View style={styles.changeTag}><Text style={styles.changeTagText}>{tag}</Text></View>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  gradient: { flex: 1 },
  safe: { flex: 1 },
  scroll: { paddingHorizontal: 24, paddingBottom: 40 },

  // Hero
  hero: { alignItems: "center", paddingTop: 12, marginBottom: 20 },
  levelBadge: { paddingHorizontal: 20, paddingVertical: 6, borderRadius: 16, marginBottom: -12, zIndex: 2 },
  levelBadgeText: { fontSize: 14, fontWeight: "900", color: "#FFFFFF", letterSpacing: 1 },
  heroPig: { width: 180, height: 180 },
  heroTitle: { fontSize: 26, fontWeight: "900", color: "#4A2040", letterSpacing: -0.5, marginTop: 8 },
  heroSub: { fontSize: 14, fontWeight: "500", color: "#8E6080", marginTop: 4 },
  statPills: { flexDirection: "row", gap: 8, marginTop: 10 },
  pill: { backgroundColor: "#FFD6EB", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 4 },
  pillText: { fontSize: 12, fontWeight: "700", color: "#FF69B4" },

  // Cards
  card: { marginBottom: 16, padding: 18 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  sectionLabel: { fontSize: 11, fontWeight: "800", color: "#B898A8", letterSpacing: 1.5, textTransform: "uppercase" },

  // Change rows
  changeRow: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "rgba(0,0,0,0.06)" },
  changeLabel: { fontSize: 10, fontWeight: "800", color: "#B898A8", letterSpacing: 1, marginBottom: 4 },
  changeValues: { flexDirection: "row", alignItems: "center", gap: 8 },
  changeLeft: { fontSize: 15, fontWeight: "600", color: "#4A2040" },
  changeArrow: { fontSize: 14, color: "#B898A8" },
  changeRight: { fontSize: 15, fontWeight: "600", color: "#4A2040" },
  changeTag: { backgroundColor: "#FF69B4", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  changeTagText: { fontSize: 9, fontWeight: "900", color: "#FFFFFF", letterSpacing: 0.5 },

  // Cosmetic unlock
  cosmeticRow: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "rgba(0,0,0,0.06)" },
  cosmeticUnlocked: { flexDirection: "row", alignItems: "center", marginBottom: 4 },
  cosmeticUnlockedText: { fontSize: 10, fontWeight: "800", color: "#FF69B4", letterSpacing: 1 },
  cosmeticName: { fontSize: 16, fontWeight: "900", color: "#4A2040" },
  cosmeticDesc: { fontSize: 12, fontWeight: "500", color: "#8E6080", marginTop: 2 },

  // XP
  xpSection: { paddingTop: 14 },
  xpHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  xpLabel: { fontSize: 10, fontWeight: "800", color: "#B898A8", letterSpacing: 1 },
  xpBadge: { fontSize: 12, fontWeight: "900", color: "#FF69B4" },
  xpLevelLabel: { fontSize: 14, fontWeight: "700", color: "#4A2040", marginBottom: 8 },
  xpBarTrack: { height: 8, borderRadius: 4, backgroundColor: "#FFD6EB", overflow: "hidden", marginBottom: 6 },
  xpBarFill: { height: "100%", borderRadius: 4 },
  xpLabels: { flexDirection: "row", justifyContent: "space-between" },
  xpSmall: { fontSize: 11, fontWeight: "500", color: "#B898A8" },

  // Achievements
  achieveCount: { fontSize: 12, fontWeight: "700", color: "#FF69B4" },
  achieveRow: { flexDirection: "row", gap: 10, flexWrap: "wrap" },
  achieveBadge: { width: (SCREEN_W - 48 - 36 - 20) / 3, backgroundColor: "#FFF5FA", borderRadius: 14, padding: 10, alignItems: "center" },
  achieveIcon: { fontSize: 22, marginBottom: 2 },
  achieveName: { fontSize: 11, fontWeight: "800", color: "#4A2040", textAlign: "center" },
  achieveDesc: { fontSize: 9, fontWeight: "500", color: "#B898A8", textAlign: "center", marginTop: 2 },

  // Share
  shareDesc: { fontSize: 13, fontWeight: "500", color: "#8E6080", marginTop: 4, marginBottom: 12 },
  shareRow: { flexDirection: "row", gap: 10 },
  shareBtn: { flex: 1, backgroundColor: "#FFD6EB", borderRadius: 12, paddingVertical: 10, alignItems: "center" },
  shareBtnText: { fontSize: 13, fontWeight: "700", color: "#FF69B4" },

  // CTA
  rewardsBtn: { marginBottom: 16, borderRadius: 20, overflow: "hidden" },
  rewardsBtnGrad: { paddingVertical: 18, alignItems: "center", borderRadius: 20 },
  rewardsBtnText: { fontSize: 16, fontWeight: "800", color: "#FFFFFF", letterSpacing: 0.5 },

  // Pig reaction
  reactionCard: { backgroundColor: "rgba(255,255,255,0.4)", borderRadius: 16, padding: 16, marginBottom: 20 },
  reactionLabel: { fontSize: 10, fontWeight: "800", color: "#FF69B4", letterSpacing: 1, marginBottom: 6 },
  reactionText: { fontSize: 14, fontWeight: "600", color: "#4A2040", lineHeight: 20, fontStyle: "italic" },
});
